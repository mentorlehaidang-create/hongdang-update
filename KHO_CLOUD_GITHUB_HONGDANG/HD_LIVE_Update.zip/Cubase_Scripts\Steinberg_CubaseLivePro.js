// =============================================================================
// HD LIVE PRO - CUBASE 12 / 13 / 14 / 15 / 16 MIDI REMOTE SCRIPT
// Tương thích hoàn toàn với Cubase Pro / Artist / Elements 12, 13, 14, 15, 16
// Cổng MIDI khuyên dùng: loopMIDI (Kênh MIDI 1)
// =============================================================================

var midiremote_api = require('midiremote_api_v1');

var driver = midiremote_api.makeDeviceDriver(
    'Steinberg',
    'CubaseLivePro',
    'HD LIVE - Cubase 12/13/14/15/16 Auto-Controller'
);

var midiInput = driver.mPorts.makeMidiInput();
var midiOutput = driver.mPorts.makeMidiOutput();

driver.makeDetectionUnit().detectPortPair(midiInput, midiOutput)
    .expectInputNameContains('HONG DANG OUT')
    .expectOutputNameContains('HONG DANG OUT');

driver.makeDetectionUnit().detectSingleInput(midiInput)
    .expectInputNameContains('HONG DANG OUT');

driver.makeDetectionUnit().detectSingleInput(midiInput)
    .expectInputNameContains('HONG DANG');

var surface = driver.mSurface;

// --- 6 NÚM VẶN (ROTARY KNOBS) TRÊN GIAO DIỆN HD LIVE ---
// 1. Vol NHẠC (CC 18)
var knobVolNhac = surface.makeKnob(0, 0, 1, 1);
knobVolNhac.mSurfaceValue.mMidiBinding.setInputPort(midiInput).bindToControlChange(0, 18);

// 2. Vol MICRO (CC 17)
var knobVolMicro = surface.makeKnob(1, 0, 1, 1);
knobVolMicro.mSurfaceValue.mMidiBinding.setInputPort(midiInput).bindToControlChange(0, 17);

// 3. FX 1 - Reverb Send (CC 14)
var knobFx1 = surface.makeKnob(2, 0, 1, 1);
knobFx1.mSurfaceValue.mMidiBinding.setInputPort(midiInput).bindToControlChange(0, 14);

// 4. FX 2 - Delay Send (CC 15)
var knobFx2 = surface.makeKnob(0, 1, 1, 1);
knobFx2.mSurfaceValue.mMidiBinding.setInputPort(midiInput).bindToControlChange(0, 15);

// 5. FLEX TUNE - Quick Control 2 (CC 19)
var knobFlexTune = surface.makeKnob(1, 1, 1, 1);
knobFlexTune.mSurfaceValue.mMidiBinding.setInputPort(midiInput).bindToControlChange(0, 19);

// 6. RETUNE SPEED - Quick Control 1 (CC 16)
var knobRetune = surface.makeKnob(2, 1, 1, 1);
knobRetune.mSurfaceValue.mMidiBinding.setInputPort(midiInput).bindToControlChange(0, 16);

// --- CÁC NÚT CHỨC NĂNG (REC, NHẠC, MICRO, VANG, KEY, SCALE) ---
var btnRecord = surface.makeButton(0, 2, 1, 1);
btnRecord.mSurfaceValue.mMidiBinding.setInputPort(midiInput).bindToControlChange(0, 118);

var btnMuteMic = surface.makeButton(1, 2, 1, 1);
btnMuteMic.mSurfaceValue.mMidiBinding.setInputPort(midiInput).bindToControlChange(0, 20);

var btnMuteMusic = surface.makeButton(2, 2, 1, 1);
btnMuteMusic.mSurfaceValue.mMidiBinding.setInputPort(midiInput).bindToControlChange(0, 21);

var btnBypassTune = surface.makeButton(0, 3, 1, 1);
btnBypassTune.mSurfaceValue.mMidiBinding.setInputPort(midiInput).bindToControlChange(0, 22);

var btnBypassFx = surface.makeButton(1, 3, 1, 1);
btnBypassFx.mSurfaceValue.mMidiBinding.setInputPort(midiInput).bindToControlChange(0, 23);

var knobTuneKey = surface.makeKnob(2, 3, 1, 1);
knobTuneKey.mSurfaceValue.mMidiBinding.setInputPort(midiInput).bindToControlChange(0, 25);

var knobTuneScale = surface.makeKnob(3, 3, 1, 1);
knobTuneScale.mSurfaceValue.mMidiBinding.setInputPort(midiInput).bindToControlChange(0, 26);

// --- KÊNH PHỤ ĐỒNG BỘ TRỰC TIẾP TRACK MIC (KHI KHÔNG CLICK CHỌN TRACK MIC) ---
var btnBypassMicSend1 = surface.makeButton(0, 4, 1, 1);
btnBypassMicSend1.mSurfaceValue.mMidiBinding.setInputPort(midiInput).bindToControlChange(0, 37);

var knobMicFx1 = surface.makeKnob(1, 4, 1, 1);
knobMicFx1.mSurfaceValue.mMidiBinding.setInputPort(midiInput).bindToControlChange(0, 29);

var knobMicFx2 = surface.makeKnob(2, 4, 1, 1);
knobMicFx2.mSurfaceValue.mMidiBinding.setInputPort(midiInput).bindToControlChange(0, 30);

var knobMicRetune = surface.makeKnob(3, 4, 1, 1);
knobMicRetune.mSurfaceValue.mMidiBinding.setInputPort(midiInput).bindToControlChange(0, 31);

var knobMicFlex = surface.makeKnob(0, 5, 1, 1);
knobMicFlex.mSurfaceValue.mMidiBinding.setInputPort(midiInput).bindToControlChange(0, 32);

var knobMicKey = surface.makeKnob(1, 5, 1, 1);
knobMicKey.mSurfaceValue.mMidiBinding.setInputPort(midiInput).bindToControlChange(0, 33);

var knobMicScale = surface.makeKnob(2, 5, 1, 1);
knobMicScale.mSurfaceValue.mMidiBinding.setInputPort(midiInput).bindToControlChange(0, 34);

var btnBypassSelSend2 = surface.makeButton(3, 5, 1, 1);
btnBypassSelSend2.mSurfaceValue.mMidiBinding.setInputPort(midiInput).bindToControlChange(0, 35);

var btnBypassMicSend2 = surface.makeButton(0, 6, 1, 1);
btnBypassMicSend2.mSurfaceValue.mMidiBinding.setInputPort(midiInput).bindToControlChange(0, 36);

// --- ÁNH XẠ VÀO CUBASE 12 / 13 / 14 / 15 / 16 MIXCONSOLE & TRANSPORT ---
var page = driver.mMapping.makePage('HD LIVE Auto-Controller (Cubase 12-16)');
var selectedTrack = page.mHostAccess.mTrackSelection.mMixerChannel;
var mixerBank = page.mHostAccess.mMixConsole.makeMixerBankZone('LiveChannels')
    .includeAudioChannels()
    .includeGroupChannels()
    .includeFXChannels();

var trackMic = mixerBank.makeMixerBankChannel();   // Kênh 1: Mic Vocal
var trackMusic = mixerBank.makeMixerBankChannel(); // Kênh 2: Nhạc Beat

// Gán FX 1 (Send 1 Reverb) & FX 2 (Send 2 Delay) cho cả Selected Track và Track Mic
page.makeValueBinding(knobFx1.mSurfaceValue, selectedTrack.mSends.getByIndex(0).mLevel);
page.makeValueBinding(knobFx2.mSurfaceValue, selectedTrack.mSends.getByIndex(1).mLevel);
page.makeValueBinding(knobMicFx1.mSurfaceValue, trackMic.mSends.getByIndex(0).mLevel);
page.makeValueBinding(knobMicFx2.mSurfaceValue, trackMic.mSends.getByIndex(1).mLevel);

// Gán Quick Controls cho VST3 Auto-Tune Pro (QC1: Retune Speed, QC2: Flex Tune, QC3: Key, QC4: Scale)
page.makeValueBinding(knobRetune.mSurfaceValue, selectedTrack.mQuickControls.getByIndex(0));
page.makeValueBinding(knobFlexTune.mSurfaceValue, selectedTrack.mQuickControls.getByIndex(1));
page.makeValueBinding(knobTuneKey.mSurfaceValue, selectedTrack.mQuickControls.getByIndex(2));
page.makeValueBinding(knobTuneScale.mSurfaceValue, selectedTrack.mQuickControls.getByIndex(3));

page.makeValueBinding(knobMicRetune.mSurfaceValue, trackMic.mQuickControls.getByIndex(0));
page.makeValueBinding(knobMicFlex.mSurfaceValue, trackMic.mQuickControls.getByIndex(1));
page.makeValueBinding(knobMicKey.mSurfaceValue, trackMic.mQuickControls.getByIndex(2));
page.makeValueBinding(knobMicScale.mSurfaceValue, trackMic.mQuickControls.getByIndex(3));

// Gán Vol MICRO & Vol NHẠC
page.makeValueBinding(knobVolMicro.mSurfaceValue, trackMic.mValue.mVolume);
page.makeValueBinding(knobVolNhac.mSurfaceValue, trackMusic.mValue.mVolume);

// Gán nút REC, MICRO, NHẠC, và VANG (Tắt/Bật Sends FX 1 & FX 2 vị trí màu xanh trên mục Sends)
page.makeValueBinding(btnRecord.mSurfaceValue, page.mHostAccess.mTransport.mValue.mRecord);
page.makeValueBinding(btnMuteMic.mSurfaceValue, trackMic.mValue.mMute);
page.makeValueBinding(btnMuteMusic.mSurfaceValue, trackMusic.mValue.mMute);
page.makeValueBinding(btnBypassFx.mSurfaceValue, selectedTrack.mSends.getByIndex(0).mOn);
page.makeValueBinding(btnBypassMicSend1.mSurfaceValue, trackMic.mSends.getByIndex(0).mOn);
page.makeValueBinding(btnBypassSelSend2.mSurfaceValue, selectedTrack.mSends.getByIndex(1).mOn);
page.makeValueBinding(btnBypassMicSend2.mSurfaceValue, trackMic.mSends.getByIndex(1).mOn);

