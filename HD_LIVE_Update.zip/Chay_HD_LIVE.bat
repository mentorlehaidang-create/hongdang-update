@echo off
chcp 65001 >nul
title HD LIVE - Cubase 12/13/14/15/16 Auto-Controller Pro
cd /d "%~dp0"

:: Kiểm tra xem máy đã có .NET 9 Desktop Runtime chưa
dotnet --list-runtimes 2>nul | findstr /i "Microsoft.WindowsDesktop.App 9." >nul
if %errorlevel% neq 0 (
    echo [!] Máy tính này chưa cài đặt .NET 9.0 Desktop Runtime.
    echo [*] Đang tự động tải và cài đặt .NET 9.0 Desktop Runtime cho bạn...
    winget install Microsoft.DotNet.DesktopRuntime.9 --accept-package-agreements --accept-source-agreements
)

start "" "%~dp0CubaseLiveController.exe"
