# 🎙️ CUBASE LIVE AUTO-CONTROLLER PRO v2.5
**Bảng điều khiển Cubase 12 / 13 / 14 & Antares Auto-Tune Pro (X / 11 / 9 / EFX+) hát live tự động**

---

## 🚀 1. Cách khởi chạy phần mềm
- **Cách nhanh nhất**: Nhấp đúp chuột vào file [`Chay_Bang_Dieu_Khien_Cubase.bat`](file:///d:/LÀM%20DAW/Chay_Bang_Dieu_Khien_Cubase.bat) hoặc chạy trực tiếp file:
  `d:\LÀM DAW\bin\Release\net9.0-windows\CubaseLiveController.exe`

---

## 🎹 2. Các tính năng chính

### A. Đổi Tone / Key Nhạc & Tự Động Dò Tone (Auto Key Detection)
1. **Bảng 12 Nốt Nhạc (`C` -> `B`) + `Major (Trưởng)` / `Minor (Thứ)`**:
   - Hiển thị sẵn **Tone Song Song (Relative Major/Minor)** ngay trên từng nút (ví dụ: `C ↔ Am`, `G ↔ Em`, `F ↔ Dm`) giúp bạn chọn đúng Tone ngay cả khi chỉ nhớ giọng Trưởng hoặc Thứ.
   - Có nút dịch Tone nhanh **`-1 Bán cung`** / **`+1 Bán cung`**.
2. **Tự Động Dò Tone Nhạc Đang Phát (`WASAPI Loopback + FFT Chromagram`)**:
   - Nhấn nút **`🎧 Bật Dò Nhạc Hệ Thống`** để phần mềm tự động lắng nghe nhạc Beat đang phát trên máy tính (YouTube, Chrome, Cubase, TikTok...) mà **không cần cài đặt dây cáp âm thanh ảo**.
   - Tích chọn **`Tự động đổi Tone Auto-Tune khi dò ổn định`**: Khi bài hát mới vang lên khoảng 1.5 giây và độ tin cậy vượt ngưỡng, phần mềm tự động đẩy Tone Trưởng/Thứ sang Auto-Tune Pro!
   - Có nút **`🎵 Test Nhạc Mẫu`** để thử nghiệm ngay khả năng phân tích phổ 12 nốt hòa âm khi chưa bật nhạc.

---

### B. Cơ Chế Điều Khiển Kép (Hybrid: MIDI Ảo + Điều Khiển Cửa Sổ Auto-Tune)

#### Cơ chế 1: Điều khiển trực tiếp cửa sổ Antares Auto-Tune Pro (`F3` & `F2`)
- **Bước 1 (Khóa cửa sổ Auto-Tune)**: Mở plugin Auto-Tune trên Cubase, đưa trỏ chuột lên cửa sổ Auto-Tune rồi bấm phím **`F3`**.
- **Bước 2 (Học tọa độ 1 lần duy nhất - mất 15 giây)**:
  1. Bấm nút **`🎯 Học Tọa Độ Nút (F2)`** trên bảng điều khiển.
  2. Trỏ chuột vào nút mở bảng **Key** trên Auto-Tune -> bấm **`F2`**.
  3. Mở bảng Key ra, trỏ chuột vào nốt **`C`** đầu tiên -> bấm **`F2`**.
  4. Trỏ chuột vào nốt **`B`** cuối cùng -> bấm **`F2`** *(Phần mềm sẽ tự động chia đều chính xác cả 12 nốt từ C đến B!)*.
  5. Trỏ chuột vào nút mở bảng **Scale** -> bấm **`F2`**.
  6. Mở bảng Scale ra, trỏ chuột vào **`Major`** -> bấm **`F2`**, rồi trỏ vào **`Minor`** -> bấm **`F2`**.
- Từ lúc này, mỗi khi bạn chọn Tone hoặc bộ dò tự động phát hiện Tone mới, phần mềm sẽ tự động tích tắc đổi Key & Scale trên Auto-Tune rồi trả con trỏ chuột về đúng vị trí cũ trong chớp mắt!

#### Cơ chế 2: Điều khiển Cubase 12 / 13 / 14 qua Cổng MIDI Ảo (`loopMIDI`)
1. Cài đặt và mở phần mềm miễn phí **loopMIDI**, nhấn dấu `+` để tạo cổng tên là `loopMIDI Port`.
2. Trên bảng điều khiển, bấm nút **`⚡ Cài Script Cubase 12/13/14`** ở thanh trên cùng.
3. Phần mềm sẽ tự động cài đặt Script chính chuẩn **`Steinberg_CubaseLivePro.js`** vào thư mục `Documents\Steinberg\Cubase\MIDI Remote\Driver Scripts\Local\Steinberg\CubaseLivePro\`.
4. Mở Cubase 12 / 13 / 14 -> Mở tab **MIDI Remote** ở dưới đáy -> Bảng điều khiển tự động kết nối với:
   - **Send 1 (CC 14)**: Độ vang **Reverb**
   - **Send 2 (CC 15)**: Độ nhại **Delay**
   - **Quick Control 1 (CC 16)**: Độ căng **Auto-Tune Retune Speed**
   - **Volume Kênh 1 & 2 (CC 17, CC 18)**: Âm lượng **Mic Vocal** & **Nhạc Beat**
   - **Mute / Bypass (CC 20..23)**: Tắt Mic, Tắt Nhạc, Ngắt Vang (Chế độ MC), Bật/Tắt Auto-Tune.

---

### C. 6 Preset Giọng Hát 1 Chạm & Phím Tắt Toàn Cục
- **`Alt + 1`** 💖 **Ballad Ngọt Ngào**: Vang sâu 68%, Delay 46%, Retune 72% (mượt mà).
- **`Alt + 2`** ⚡ **Remix / Vinahouse**: Vang 50%, Delay 58%, Retune 95% (Auto-Tune căng, ảo).
- **`Alt + 3`** 🌸 **Bolero / Trữ Tình**: Vang ngân 78%, Delay 64%, Retune 52% (giữ độ luyến láy tự nhiên).
- **`Alt + 4`** 🎧 **Rap / R&B Lofi**: Vang 28%, Delay 24%, Retune 85% (rõ chữ, bắt nhịp chắc).
- **`Alt + 5`** 🎙️ **Giọng MC / Giao Lưu**: Tự động ngắt Vang & tắt Auto-Tune để nói chuyện với khán giả không bị vọng.
- **`Alt + 6`** ⭐ **Tùy Chỉnh (Custom)**: Lưu thông số riêng của bạn bằng nút **`💾 Lưu Vào Preset Đang Chọn`**.
- **Phím tắt khẩn cấp toàn cục** (hoạt động ngay cả khi bạn đang mở trình duyệt hoặc Cubase):
  - **`F9`**: Tắt / Bật tiếng Mic khẩn cấp (`MUTE MIC`).
  - **`F10`**: Bật / Tắt chế độ nói chuyện MC (`NGẮT VANG FX`).

---

### D. Soundboard Hiệu Ứng Livestream (8 Nút)
- Tích hợp sẵn bộ tổng hợp âm thanh DSP cho 8 hiệu ứng: **👏 Vỗ Tay Lớn, 😂 Tiếng Cười Hài, 📢 Kèn Airhorn, 🥳 Reo Hò, 🥁 Trống Troll (Ba Dum Tss), 🦆 Quê Độ (Sad Horn), 🔔 Chuông Đúng Rồi, 🚀 Drop Laser**.
- **Chuột trái**: Phát ngay lập tức.
- **Chuột phải vào bất kỳ nút nào**: Mở hộp thoại chọn file `.mp3` hoặc `.wav` bất kỳ trong máy tính của bạn để gán vào nút đó!
